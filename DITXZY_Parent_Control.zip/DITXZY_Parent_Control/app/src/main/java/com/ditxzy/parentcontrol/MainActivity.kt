package com.ditxzy.parentcontrol

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var flashOn = false
    private var cameraId: String? = null
    private lateinit var cameraManager: CameraManager
    private lateinit var flashButton: Button
    private val blue = Color.rgb(0, 210, 255)
    private val bg = Color.rgb(8, 10, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 24); setBackgroundColor(bg) }
        val title = TextView(this).apply { text = "DITXZY PARENT CONTROL"; textSize = 23f; setTextColor(blue); gravity = Gravity.CENTER; setPadding(0, 10, 0, 8) }
        val sub = TextView(this).apply { text = "Kontrol penggunaan perangkat dengan izin yang jelas"; textSize = 13f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 24) }
        root.addView(title); root.addView(sub)
        flashButton = makeButton("FLASH: MATI") { toggleFlash() }; root.addView(flashButton)
        root.addView(makeButton("PERINGATAN TIDUR (atur 21:00)") { scheduleSleepReminder() })
        root.addView(makeButton("PENGATURAN BATAS APLIKASI") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            Toast.makeText(this, "Aktifkan akses penggunaan secara sadar. Pemblokiran penuh perlu kontrol orang tua Android.", Toast.LENGTH_LONG).show()
        })
        root.addView(makeButton("PENGATURAN KUNCI LAYAR") {
            startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
            Toast.makeText(this, "Gunakan kunci layar Android. Aplikasi ini tidak mengunci perangkat diam-diam.", Toast.LENGTH_LONG).show()
        })
        val note = TextView(this).apply {
            text = "Catatan: fitur blokir aplikasi dan penguncian paksa memerlukan konfigurasi resmi Android/Family Link atau izin administrator perangkat. Tidak ada penguncian tersembunyi. Flash hanya digunakan saat tombol aktif dan dapat dihentikan kapan saja."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(4, 18, 4, 0)
        }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(0, 85, 115)); textSize = 14f
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 8, 0, 8) }
        setOnClickListener { action() }
    }

    private fun toggleFlash() {
        val id = cameraId
        if (id == null) { Toast.makeText(this, "Perangkat tidak memiliki flash yang tersedia", Toast.LENGTH_SHORT).show(); return }
        try {
            flashOn = !flashOn
            cameraManager.setTorchMode(id, flashOn)
            flashButton.text = if (flashOn) "FLASH: NYALA — KETUK UNTUK MATIKAN" else "FLASH: MATI"
        } catch (_: Exception) {
            flashOn = false
            Toast.makeText(this, "Flash tidak dapat digunakan saat ini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleSleepReminder() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, SleepReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(this, 12, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 21); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Izinkan jadwal alarm, lalu tekan tombol lagi", Toast.LENGTH_LONG).show()
                return
            }
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            Toast.makeText(this, "Pengingat tidur dijadwalkan pukul 21:00", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak bisa menjadwalkan alarm. Periksa izin alarm/notifikasi.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        if (flashOn && cameraId != null) try { cameraManager.setTorchMode(cameraId!!, false) } catch (_: Exception) {}
        super.onDestroy()
    }
}
