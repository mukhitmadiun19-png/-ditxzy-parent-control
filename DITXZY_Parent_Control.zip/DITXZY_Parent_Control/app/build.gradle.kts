plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ditxzy.parentcontrol"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ditxzy.parentcontrol"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
