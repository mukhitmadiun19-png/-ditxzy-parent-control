DITXZY PARENT CONTROL — SOURCE PROJECT ANDROID

ISI FITUR
- Flash: nyala/mati manual, bukan strobo otomatis.
- Pengingat tidur: jadwal sekali untuk pukul 21:00 berikutnya; tekan lagi untuk jadwalkan ulang.
- Pengaturan batas aplikasi: membuka halaman akses penggunaan Android sebagai titik awal. Ini BELUM memblokir aplikasi secara otomatis.
- Pengaturan kunci layar: membuka pengaturan keamanan Android. Aplikasi tidak mengunci HP secara paksa/diam-diam.

CARA MEMBUAT APK (Android Studio)
1. Ekstrak ZIP ini.
2. Buka Android Studio, pilih Open, lalu pilih folder DITXZY_Parent_Control.
3. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan JDK yang disarankan Android Studio.
4. Pilih Build > Build APK(s).
5. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.
6. Pasang hanya pada perangkat milik sendiri/anak yang penggunaannya dikelola dengan sepengetahuan mereka dan sesuai aturan keluarga.

CATATAN PENTING
- Ini adalah source project, bukan APK yang sudah dikompilasi.
- Untuk pembatasan aplikasi yang sungguh-sungguh, gunakan Google Family Link atau solusi parental control resmi. Android membatasi aplikasi biasa agar tidak bisa diam-diam memblokir aplikasi lain atau mengunci perangkat.
- Pengingat notifikasi membutuhkan izin notifikasi pada Android versi baru. Jadwal alarm dapat meminta izin tambahan.
- Flash manual bisa mengganggu atau berisiko bagi orang yang sensitif terhadap cahaya; matikan segera jika tidak nyaman.
